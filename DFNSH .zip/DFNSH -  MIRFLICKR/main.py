from train.hash_train_S_adv import Trainer


if __name__ == "__main__":
    print("train.hash_train_S_adv")
    Trainer()





