import shutil
import sys
import argparse
import requests
from PIL import Image as PILImage
from io import BytesIO
import os


def get_opt():
    """参数设置"""
    parse = argparse.ArgumentParser()
    parse.add_argument("--cache_path", type=str, default="/root/autodl-tmp/DCHMT-main/dataset/nuswide/images", help="缓存文件路径")
    parse.add_argument("--image_urls", type=list, default="/root/autodl-tmp/DCHMT-main/dataset/nuswide/NUS-WIDE-urls.txt", help="请求的图像链接")
    opt = parse.parse_args()
    return opt


def main():
    # 获取配置信息
    opt = get_opt()
    # 本地缓存路径
    cache_path = opt.cache_path

    # 清除现有的缓存文件夹(如果有的话)
    try:
        shutil.rmtree(cache_path)
    except:
        pass
    # 创建缓存文件夹
    os.makedirs(cache_path)

    # 获取图像链接
    if opt.image_urls:
        image_urls = opt.image_urls
    else:
        while True:
            input_id = int(input("The following options:\n [0]: stop running. \n [1]: use default config.\nPlease enter the correct option: "))

            if input_id == 0:
                sys.exit()  # 退出程序
                # break
            # elif input_id == 1:
            #     image_urls = [
            #         f"https://univs-news-1256833609.cos.ap-beijing.myqcloud.com/123/upload/resources/image/{7467914 + i * 2}.jpg"
            #         for i in range(50)
            #     ]
            #     break  # 输入正确，跳出循环
            else:
                print("input number is wrong，please input correct.\n")

    # 遍历下载图像
    id = 1
    for i, image_url in enumerate(image_urls):
        # 发起HTTP请求获取图像数据
        print("i===", i)
        print("image_url====", image_url)
        response = requests.get(image_url)
        if response.status_code == 200:
            # 将图像数据转换为PIL Image对象
            image_data = BytesIO(response.content)
            image = PILImage.open(image_data)
            # 可以将 image 用于展示、保存或进一步处理
            image.save(f"./{cache_path}/{id}_{image_url.rsplit('/', 1)[1][:-4]}.png")  # 保存图像
            id += 1
        else:
            # 请求不到的数据进行错误返回
            print(f"Failed to download image: {i}_{image_url}")


if __name__ == '__main__':
    main()