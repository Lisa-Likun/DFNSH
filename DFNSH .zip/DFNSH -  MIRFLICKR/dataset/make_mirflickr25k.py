import os
import scipy.io as scio
import numpy as np

# mirflickr25k_annotations_v080 and mirflickr
# mkdir mat
# mv make_mirflickr25k.py mat
# python make_mirflickr25k.py
root_dir = "/root/autodl-tmp/dataset"

file_path = os.path.join(root_dir, "mirflickr25k_annotations_v080")
print("file_path", file_path)
file_list = os.listdir(file_path)
print("file_list", file_list)
file_list = [item for item in file_list if "_r1" not in item and "README" not in item]

print("class num:", len(file_list))

class_index = {}
for i, item in enumerate(file_list):
    class_index.update({item: i})

label_dict = {}
for path_id in file_list:
    path = os.path.join(file_path, path_id)
    with open(path, "r") as f:
        for item in f:
            item = item.strip()
            if item not in label_dict:
                label = np.zeros(len(file_list))
                label[class_index[path_id]] = 1
                label_dict.update({item: label})
            else:
                # print()
                label_dict[item][class_index[path_id]] = 1

# print(label_dict)
print("create label:", len(label_dict))
keys = list(label_dict.keys())
keys.sort()

labels = []
for key in keys:
    labels.append(label_dict[key])
print("labels created:", len(labels))
labels = {"category": labels}


PATH = os.path.join(root_dir, "flickr25k/mirflickr")
index = [os.path.join(PATH, "im" + item + ".jpg") for item in keys]
print("index created:", len(index))
index= {"index": index}

# root_dir = "D:\Hash code\Dataset"
# captions_path = os.path.join(root_dir, "mirflickr\meta/tags")
captions_path = os.path.join(PATH, "meta")
captions_path = os.path.join(captions_path, "tags")
print("captions_path:", captions_path)
captions_list = os.listdir(captions_path)
print("captions_list:", captions_list)
captions_dict = {}
for item in captions_list:
    print("item:", item)
    id_ = item.split(".")[0].replace("tags", "")
    # print("id_：", id_)
    caption = ""
    cit_path = os.path.join(captions_path, item)
    # print(" cit_path:",  cit_path)
    with open(cit_path, mode='r', encoding='utf-8') as f:
        for word in f.readlines():
            caption += word.strip() + " "
    caption = caption.strip()
    captions_dict.update({id_: caption})


captions = []

for item in keys:
    captions.append([captions_dict[item]])

print("captions created:", len(captions))
captions = {"caption": captions}
print(root_dir)
path_index = "/root/autodl-tmp/dataset/flickr25k/index.mat"
path_caption = "/root/autodl-tmp/dataset/flickr25k/caption.mat"
path_label = "/root/autodl-tmp/dataset/flickr25k/label.mat"
scio.savemat(path_index, index)
scio.savemat(path_caption, captions)
scio.savemat(path_label, labels)