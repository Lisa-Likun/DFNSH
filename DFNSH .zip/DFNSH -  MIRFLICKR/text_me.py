import numpy as np
import torch

# a = torch.ones(5)
# print(a)
#
# b = a.numpy()
# print(b)
#
#
# c = np.append(b,0)
# print(c)




bs1 = [1,2,3]
ss_matrix = torch.tensor(np.ones((64, 64)) * -1)
for ss in range(10):
    amn = ss_matrix[ss][:2]
    bs11 = np.append(bs1,3)
    bs1=bs11
